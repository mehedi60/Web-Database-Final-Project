<?php
include("config.php");
session_start();

$user=$_POST['uname'];
$password=$_POST['pass'];

$sql="SELECT * FROM signup WHERE uname='$user' AND pass='$password' ";
$result=mysqli_query($myconn,$sql);


$count=mysqli_num_rows($result);
    
    echo ($count);
    
if($count===1)
{
	$_SESSION['user']=$user;
	header("location:../view/customer_view.php");
}
else
	{
		echo'pasword or user name wrong <a href="../view/login.php"> Please try again</a>';
	}

?>